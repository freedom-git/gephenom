<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>UploadiFive Test</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="jquery.uploadify.min.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="uploadify.css">
<style type="text/css">
body {
	font: 13px Arial, Helvetica, Sans-serif;
}
</style>
</head>

<body>
	<h1>Uploadify Demo</h1>
	<form>
		<div id="queue"></div>
		<input id="file_upload" name="file_upload" type="file" multiple="true">
        <input name="" id="ok"  type="button">
	</form>

	<script type="text/javascript">
		<?php $timestamp = time();?>
		$(function() {
			
			
			$('#file_upload').uploadify({
				'formData'     : {
					'timestamp' : '<?php echo $timestamp;?>',
					'token'     : '<?php echo md5('unique_salt' . $timestamp);?>'
				},
				'debug'    : true,
				'swf'      : 'uploadify.swf',
				'uploader' : 'uploadify.php',
				'fileType'     : 'image',
				'auto':false,
				'fileTypeExts':'*.jpg;*.jpeg;*.png;*.gif',
				 'onSelect': function(e)
				{
					alert("唯一标识:" + e.id + "\r\n" +
						  "文件名：" + e.name + "\r\n" +
						  "文件大小：" + e.size + "\r\n" +
						  "创建时间：" + e.creationDate + "\r\n" +
						  "最后修改时间：" + e.modificationDate + "\r\n" +
						  "文件类型：" + e.type)
				},'onUploadSuccess' : function(file, data, response) {  
					alert('The file ' + file.name + ' uploaded successfully.');
				}
					
			});
			
			$("#ok").click(function(){
					$('#file_upload').uploadify('upload');
				});
		});
	</script>
</body>
</html>